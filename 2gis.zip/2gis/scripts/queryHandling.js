DG.then(function () {
    const MAX_DISP_MARKERS = 1000; //максимальное количество отображаемых маркеров при большом количестве данных

    map = DG.map('map', {
        center: [55.75, 37.58],
        zoom: 11,
        fullscreenControl: false
    });
    map.whenReady(function() {
        document.forms.searchForm.hidden = false;
    });

    var searchButton  = document.querySelector('#searchButton'),
        searchField   = document.querySelector('#searchField'),
        removeButton  = document.querySelector('#removeTextButton'),
        isFirstSearch = true, //флаг первого поиска
        allMarkers  = [], //массив для всех маркеров, сформированных по данным из запроса

        //переменная wrapListener используется для сохранения функции-обработчика (обертки) из showMoreMarkers.bind().
        //Необходима для последующего удаления eventListener c этой функцией.
        wrapListener = null;

    searchField.oninput = function() {
        if(searchField.value) {
            removeButton.hidden = false;
        } else {
            removeButton.hidden = true;
        }
    };

    removeButton.onclick = function() {
        searchField.value = '';
        if(searchField.classList.contains('notFound')) {
            searchField.classList.remove('notFound');
        }
        removeButton.hidden = true;
    };

    searchField.onkeydown = function(event) {
        if(event.keyCode === 13) {
            event.preventDefault();
            searchButton.click();
        }
    };

    function searchThis(wantedData) {
        return new Promise(function(resolve, reject) {
            var xhr = new XMLHttpRequest();

            xhr.open('POST', 'http://catalog.api.2gis.ru/2.0/catalog/marker/search?q=' + wantedData + '&page_size=15000&region_id=32&key=ruhebf8058', true);
            xhr.setRequestHeader('Content-type', 'application/json; charset=utf-8');

            xhr.onreadystatechange = function() {
                if(this.readyState === XMLHttpRequest.DONE) {
                    if(this.status === 200) {
                        resolve(this.response);
                    } else {
                        reject(this.status);
                    }
                }
            };

            xhr.send();
        })
    }

    //Функция удаления маркеров пердыдущего запроса с карты
    function deleteMarkers(markers) {
        for(var i = 0; i < markers.length; i++) {
            map.removeLayer(markers[i]);
        }
    }

    searchButton.onclick = async function() {

        if(searchField.classList.contains('notFound')) {
            searchField.classList.remove('notFound');
        }

        //если поисковая строка не пустая и не состоит из пробелов, то выполняем запрос
        if(searchField.value && searchField.value.trim().length) {
            try {
                var responseData  = await searchThis(searchField.value),
                    parsedData    = JSON.parse(responseData),
                    markersCoords = []; //массив координат из данных результата запроса

                //если запрос удачный, то добавляем маркеры, если нет, то полю ввода текста поиска
                //добавляется класс "notFound", который заменяет у него бэкграунд
                if(parsedData.meta.code === 200) {

                    if(!isFirstSearch) { //если поиск не первый
                        //то удаляем маркеры предыдущего запроса
                        deleteMarkers(allMarkers);
                        allMarkers  = []; //обнуляем массив маркеров от результата поиска предыдущего запроса
                        if(wrapListener) {
                            //удаляем eventListener и функцию-обработчик, чтобы не дублировать eventListener при следующем запросе с количеством результатов
                            //> MAX_DISP_MARKERS, а также чтобы не привязывать eventListener к запросам с количеством результатов < MAX_DISP_MARKERS
                            map.off('moveend', wrapListener);
                            wrapListener = null;
                        } else {
                            //удаляем eventListener с функцией hideIntersectMarkers, чтобы не дублировать его выполнение
                            //в функции showMoreMarkers при условии, что перед запросом с большим количеством результатов (> MAX_DISP_MARKERS)
                            //был выполнен запрос с количеством результатов < MAX_DISP_MARKERS; а также чтобы не дублировать eventListener при
                            //выполнении следующего запроса с количеством результатов < MAX_DISP_MARKERS
                            map.off('zoomend', hideIntersectMarkers);
                        }
                    } else {
                        isFirstSearch = false;
                    }

                    parsedData.result.items.forEach(function(item) { //для каждого результата поиска
                        //добавляем сформированный маркер в массив
                        allMarkers.push(DG.marker([item.lat, item.lon]).bindPopup(item.id));

                        //добавляем координаты в массив для метода fitBounds
                        markersCoords.push([item.lat, item.lon]);
                    });

                    //выполняем первичное отображение маркеров после выполнения запроса
                    var i;
                    if(allMarkers.length > MAX_DISP_MARKERS) {
                        //добавляем обработчики для подробного отображения маркеров на карте,
                        //когда количество данных в результате запроса превышает значение MAX_DISP_MARKERS.
                        //Отображение маркеров произойдет после выполнения метода fitBounds()

                        //сохраняем обертку функции-обработчика и привязываем ее к событию moveend
                        wrapListener = showMoreMarkers.bind(null, map, allMarkers, MAX_DISP_MARKERS);
                        map.on('moveend', wrapListener);
                    } else {
                        for(i = 0; i < allMarkers.length; i++) {
                            allMarkers[i].addTo(map);
                        }
                        //добавляем обработчик для запроса с количеством результатов < MAX_DISP_MARKERS, т.е.
                        //для такого запроса подключаем только функционал сокрытия пересекающихся маркеров
                        map.on('zoomend', hideIntersectMarkers);
                    }

                    //отображаем на карте область, в которую входят все координаты маркеров
                    map.fitBounds(markersCoords);

                    //далее выполняем функцию сокрытия перекрывающихся маркеров для случая, когда при выполнении
                    //функции fitBounds() не были вызваны ивенты zoom и move (например, когда области отображения маркеров
                    //предыдущего и текущего запросов совпадают)
                    hideIntersectMarkers();
                } else {
                    searchField.classList.add('notFound');
                    searchField.value = 'Не найдено: ' + searchField.value;
                }
            } catch(status) {
                alert('Не удалось выполнить запрос. Попробуйте позже.');
            }
        }
    };
});





