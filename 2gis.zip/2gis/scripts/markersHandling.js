function hideIntersectMarkers() {
    var markerNodes = document.querySelector('.leaflet-marker-pane').children,
        markersData = [];

    //формируем массив из объектов, которые описывают маркер: элемент DOM + координаты относительно окна браузера
    [].forEach.call(markerNodes, function(item) {
        var coords = item.getBoundingClientRect(),
            marker = {node: item, bound: DG.bounds([coords.left, coords.top], [coords.right, coords.bottom]), visibility: true};
        markersData.push(marker);
    });

    //
    markersData.forEach(function(marker, i) {
        if(marker.visibility) {
            marker.node.style.visibility = 'visible';
            for(var j = i + 1; j < markersData.length; j++) {
                if(marker.bound.intersects(markersData[j].bound)) {
                    markersData[j].visibility = false;
                    markersData[j].node.style.visibility = 'hidden';
                }
            }
        }
    });
}


function showMoreMarkers(map, markers, maxLenght) {
    var mapBounds = map.getBounds(),
        addedMarkers = 0;

    map.eachLayer(function(layer) {
        if(layer instanceof DG.Marker) {
            map.removeLayer(layer);
        }
    });

    for(var i = 0; i < markers.length; i++) {
        if(maxLenght > addedMarkers) {
            if(mapBounds.contains(markers[i].getLatLng())) {
                markers[i].addTo(map);
                addedMarkers++;
            }
        } else {
            break;
        }
    }
    //после добавления новых маркеров на крату, выполняем функцию сокрытия перекрывающихся маркеров
    hideIntersectMarkers();
}